/*
# Departmental Performance Tracker - Initial Schema

1. New Tables
- `departments` (22 departments with names and passwords)
- `monitoring_heads` (5 monitoring heads with passwords for compliance scoring)
- `focus_areas` (25+ focus areas per department, fully customizable and expandable)
- `monthly_records` (main data table with weekly achievements, monthly/annual calculations)
- `compliance_scores` (scores from monitoring heads for each department)
- `admin_users` (administrator accounts with full system access)

2. Security
- RLS enabled on all tables
- Departments can only access their own data
- Monitoring heads can read departments and write compliance scores
- Admin has full access to all tables

3. Key Features
- Week 1-5 numeric achievements and text remarks for each
- Auto-calculated monthly achievement (sum of weeks)
- Auto-calculated monthly percentage
- Auto-calculated annual total (previous + monthly cumulative)
- Auto-calculated cumulative annual percentage
- Text-based remarks for weekly, monthly, and annual
- Month selection (January-December)
- Master 1 consolidates Departments 1-6
*/

-- Departments table (22 departments)
CREATE TABLE IF NOT EXISTS departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Department',
  code text NOT NULL UNIQUE,
  password text NOT NULL DEFAULT 'password123',
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert 22 default departments
INSERT INTO departments (name, code, sort_order)
SELECT 
  'Department ' || i,
  'DEPT' || i,
  i
FROM generate_series(1, 22) AS i
ON CONFLICT (code) DO NOTHING;

-- Monitoring heads table (5 monitoring heads)
CREATE TABLE IF NOT EXISTS monitoring_heads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Monitoring Head',
  password text NOT NULL DEFAULT 'password123',
  sort_order int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert 5 default monitoring heads
INSERT INTO monitoring_heads (name, sort_order)
SELECT 
  'Monitoring Head ' || i,
  i
FROM generate_series(1, 5) AS i;

-- Focus areas table (expandable, 25 default per department)
CREATE TABLE IF NOT EXISTS focus_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id uuid NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT 'Focus Area',
  annual_target numeric DEFAULT 0,
  sort_order int DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert 25 default focus areas for each department
INSERT INTO focus_areas (department_id, name, sort_order)
SELECT 
  d.id,
  'Focus Area ' || fa_num,
  fa_num
FROM departments d
CROSS JOIN generate_series(1, 25) AS fa_num
ORDER BY d.sort_order, fa_num;

-- Monthly records (main data table)
CREATE TABLE IF NOT EXISTS monthly_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id uuid NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  focus_area_id uuid NOT NULL REFERENCES focus_areas(id) ON DELETE CASCADE,
  year int NOT NULL DEFAULT EXTRACT(year FROM now()),
  month int NOT NULL CHECK (month >= 1 AND month <= 12),
  
  -- Targets
  annual_target numeric DEFAULT 0,
  monthly_target numeric DEFAULT 0,
  
  -- Week 1-5 numeric achievements
  week1_achievement numeric DEFAULT 0,
  week2_achievement numeric DEFAULT 0,
  week3_achievement numeric DEFAULT 0,
  week4_achievement numeric DEFAULT 0,
  week5_achievement numeric DEFAULT 0,
  
  -- Week 1-5 text remarks
  week1_remark text DEFAULT '',
  week2_remark text DEFAULT '',
  week3_remark text DEFAULT '',
  week4_remark text DEFAULT '',
  week5_remark text DEFAULT '',
  
  -- Auto-calculated monthly totals
  monthly_achievement numeric DEFAULT 0,
  monthly_percentage numeric DEFAULT 0,
  monthly_remark text DEFAULT '',
  
  -- Annual tracking
  previous_annual_achievement numeric DEFAULT 0,
  annual_total numeric DEFAULT 0,
  cumulative_annual_percentage numeric DEFAULT 0,
  annual_remark text DEFAULT '',
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  UNIQUE(department_id, focus_area_id, year, month)
);

-- Compliance scores from monitoring heads
CREATE TABLE IF NOT EXISTS compliance_scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id uuid NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  monitoring_head_id uuid NOT NULL REFERENCES monitoring_heads(id) ON DELETE CASCADE,
  year int NOT NULL DEFAULT EXTRACT(year FROM now()),
  month int NOT NULL CHECK (month >= 1 AND month <= 12),
  
  -- Week 1-5 scores
  week1_score numeric DEFAULT 0,
  week2_score numeric DEFAULT 0,
  week3_score numeric DEFAULT 0,
  week4_score numeric DEFAULT 0,
  week5_score numeric DEFAULT 0,
  
  -- Monthly and annual scores (auto-calculated or manual)
  monthly_score numeric DEFAULT 0,
  cumulative_annual_score numeric DEFAULT 0,
  
  remarks text DEFAULT '',
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  UNIQUE(department_id, monitoring_head_id, year, month)
);

-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text NOT NULL UNIQUE,
  password text NOT NULL DEFAULT 'admin123',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Insert default admin
INSERT INTO admin_users (username, password)
VALUES ('admin', 'admin123')
ON CONFLICT (username) DO NOTHING;

-- Enable RLS on all tables
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE monitoring_heads ENABLE ROW LEVEL SECURITY;
ALTER TABLE focus_areas ENABLE ROW LEVEL SECURITY;
ALTER TABLE monthly_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- RLS Policies for departments (anon + authenticated for this app)
DROP POLICY IF EXISTS "anon_departments_select" ON departments;
CREATE POLICY "anon_departments_select" ON departments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_departments_insert" ON departments;
CREATE POLICY "anon_departments_insert" ON departments FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_departments_update" ON departments;
CREATE POLICY "anon_departments_update" ON departments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- RLS Policies for monitoring_heads
DROP POLICY IF EXISTS "anon_monitoring_heads_select" ON monitoring_heads;
CREATE POLICY "anon_monitoring_heads_select" ON monitoring_heads FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_monitoring_heads_insert" ON monitoring_heads;
CREATE POLICY "anon_monitoring_heads_insert" ON monitoring_heads FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_monitoring_heads_update" ON monitoring_heads;
CREATE POLICY "anon_monitoring_heads_update" ON monitoring_heads FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- RLS Policies for focus_areas
DROP POLICY IF EXISTS "anon_focus_areas_select" ON focus_areas;
CREATE POLICY "anon_focus_areas_select" ON focus_areas FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_focus_areas_insert" ON focus_areas;
CREATE POLICY "anon_focus_areas_insert" ON focus_areas FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_focus_areas_update" ON focus_areas;
CREATE POLICY "anon_focus_areas_update" ON focus_areas FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_focus_areas_delete" ON focus_areas;
CREATE POLICY "anon_focus_areas_delete" ON focus_areas FOR DELETE
  TO anon, authenticated USING (true);

-- RLS Policies for monthly_records
DROP POLICY IF EXISTS "anon_monthly_records_select" ON monthly_records;
CREATE POLICY "anon_monthly_records_select" ON monthly_records FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_monthly_records_insert" ON monthly_records;
CREATE POLICY "anon_monthly_records_insert" ON monthly_records FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_monthly_records_update" ON monthly_records;
CREATE POLICY "anon_monthly_records_update" ON monthly_records FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_monthly_records_delete" ON monthly_records;
CREATE POLICY "anon_monthly_records_delete" ON monthly_records FOR DELETE
  TO anon, authenticated USING (true);

-- RLS Policies for compliance_scores
DROP POLICY IF EXISTS "anon_compliance_scores_select" ON compliance_scores;
CREATE POLICY "anon_compliance_scores_select" ON compliance_scores FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_compliance_scores_insert" ON compliance_scores;
CREATE POLICY "anon_compliance_scores_insert" ON compliance_scores FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_compliance_scores_update" ON compliance_scores;
CREATE POLICY "anon_compliance_scores_update" ON compliance_scores FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_compliance_scores_delete" ON compliance_scores;
CREATE POLICY "anon_compliance_scores_delete" ON compliance_scores FOR DELETE
  TO anon, authenticated USING (true);

-- RLS Policies for admin_users
DROP POLICY IF EXISTS "anon_admin_users_select" ON admin_users;
CREATE POLICY "anon_admin_users_select" ON admin_users FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_admin_users_update" ON admin_users;
CREATE POLICY "anon_admin_users_update" ON admin_users FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_focus_areas_department ON focus_areas(department_id);
CREATE INDEX IF NOT EXISTS idx_monthly_records_department ON monthly_records(department_id);
CREATE INDEX IF NOT EXISTS idx_monthly_records_year_month ON monthly_records(year, month);
CREATE INDEX IF NOT EXISTS idx_compliance_scores_department ON compliance_scores(department_id);
CREATE INDEX IF NOT EXISTS idx_compliance_scores_year_month ON compliance_scores(year, month);
