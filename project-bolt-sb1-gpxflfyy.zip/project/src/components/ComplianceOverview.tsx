import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Department, ComplianceScore, MonitoringHead } from '../types';
import { MONTHS, CURRENT_YEAR } from '../types';
import { RefreshCw, Printer, Download } from 'lucide-react';

export function ComplianceOverview() {
  const [year, setYear] = useState(CURRENT_YEAR);
  const [month, setMonth] = useState(new Date().getMonth());
  const [departments, setDepartments] = useState<Department[]>([]);
  const [scores, setScores] = useState<ComplianceScore[]>([]);
  const [monitors, setMonitors] = useState<MonitoringHead[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [deptRes, scoreRes, monRes] = await Promise.all([
        supabase.from('departments').select('*').order('sort_order'),
        supabase.from('compliance_scores').select('*').eq('year', year).eq('month', month + 1),
        supabase.from('monitoring_heads').select('*').order('sort_order'),
      ]);

      if (deptRes.data) setDepartments(deptRes.data);
      if (scoreRes.data) setScores(scoreRes.data);
      if (monRes.data) setMonitors(monRes.data);
    } catch (err) {
      console.error('Error fetching compliance overview:', err);
    }
    setLoading(false);
  }, [year, month]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const getScore = (deptId: string, monitorId: string): number => {
    const score = scores.find(s => s.department_id === deptId && s.monitoring_head_id === monitorId);
    return score?.monthly_score || 0;
  };

  const getDepartmentTotal = (deptId: string): number => {
    const deptScores = scores.filter(s => s.department_id === deptId);
    return deptScores.reduce((sum, s) => sum + (s.monthly_score || 0), 0);
  };

  const getMonitorTotal = (monitorId: string): number => {
    const monScores = scores.filter(s => s.monitoring_head_id === monitorId);
    return monScores.reduce((sum, s) => sum + (s.monthly_score || 0), 0);
  };

  const handlePrint = () => window.print();

  const handleExport = () => {
    const csvRows = [
      ['Department', ...monitors.map(m => m.name), 'Total'],
      ...departments.map(dept => [
        dept.name,
        ...monitors.map(m => getScore(dept.id, m.id).toString()),
        getDepartmentTotal(dept.id).toString(),
      ]),
      ['TOTAL', ...monitors.map(m => getMonitorTotal(m.id).toString()), ''],
    ];
    const csvContent = csvRows.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Compliance_Overview_${MONTHS[month]}_${year}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 text-teal-500 animate-spin" />
      </div>
    );
  }

  const grandTotal = scores.reduce((sum, s) => sum + (s.monthly_score || 0), 0);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Compliance Overview</h1>
          <p className="text-slate-400">All monitoring head scores by department</p>
        </div>
        <div className="flex items-center gap-4">
          <select
            value={year}
            onChange={(e) => setYear(parseInt(e.target.value))}
            className="px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-xl text-white"
          >
            {[CURRENT_YEAR - 1, CURRENT_YEAR, CURRENT_YEAR + 1].map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
          <select
            value={month}
            onChange={(e) => setMonth(parseInt(e.target.value))}
            className="px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-xl text-white"
          >
            {MONTHS.map((m, i) => (
              <option key={i} value={i}>{m}</option>
            ))}
          </select>
          <button
            onClick={handleExport}
            className="flex items-center gap-2 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl transition-colors"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-colors"
          >
            <Printer className="w-4 h-4" />
            Print
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="p-4 bg-gradient-to-br from-teal-600/20 to-teal-800/20 border border-teal-500/30 rounded-xl">
          <p className="text-teal-400 text-sm">Total Compliance Score</p>
          <p className="text-3xl font-bold text-white mt-1">{grandTotal}</p>
        </div>
        <div className="p-4 bg-gradient-to-br from-emerald-600/20 to-emerald-800/20 border border-emerald-500/30 rounded-xl">
          <p className="text-emerald-400 text-sm">Avg Per Department</p>
          <p className="text-3xl font-bold text-white mt-1">{(grandTotal / departments.length).toFixed(1)}</p>
        </div>
        <div className="p-4 bg-gradient-to-br from-blue-600/20 to-blue-800/20 border border-blue-500/30 rounded-xl">
          <p className="text-blue-400 text-sm">Avg Per Monitor</p>
          <p className="text-3xl font-bold text-white mt-1">{(grandTotal / monitors.length).toFixed(1)}</p>
        </div>
        <div className="p-4 bg-gradient-to-br from-amber-600/20 to-amber-800/20 border border-amber-500/30 rounded-xl">
          <p className="text-amber-400 text-sm">Scores Recorded</p>
          <p className="text-3xl font-bold text-white mt-1">{scores.filter(s => s.monthly_score > 0).length}</p>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl overflow-hidden print:bg-white">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-800/50 print:bg-gray-200">
                <th className="px-3 py-3 text-left text-slate-300 font-medium border-r border-slate-700 print:border-gray-400 sticky left-0 bg-slate-800/50 print:bg-gray-200 z-10">
                  S/N
                </th>
                <th className="px-3 py-3 text-left text-slate-300 font-medium border-r border-slate-700 print:border-gray-400 sticky left-[40px] bg-slate-800/50 print:bg-gray-200 z-10 min-w-[200px]">
                  Department
                </th>
                {monitors.map((m) => (
                  <th key={m.id} className="px-3 py-3 text-center text-blue-400 font-medium border-r border-slate-700 print:border-gray-400 min-w-[100px]">
                    {m.name}
                  </th>
                ))}
                <th className="px-3 py-3 text-center text-teal-400 font-medium min-w-[80px]">
                  Total
                </th>
              </tr>
            </thead>
            <tbody>
              {departments.map((dept, idx) => {
                const total = getDepartmentTotal(dept.id);
                return (
                  <tr key={dept.id} className="border-t border-slate-700/50 print:border-gray-300 hover:bg-slate-700/20">
                    <td className="px-3 py-2 text-slate-400 border-r border-slate-700/50 print:border-gray-400 sticky left-0 bg-slate-800/30 print:bg-white">
                      {idx + 1}
                    </td>
                    <td className="px-3 py-2 text-white print:text-black border-r border-slate-700/50 print:border-gray-400 sticky left-[40px] bg-slate-800/30 print:bg-white z-10 font-medium">
                      {dept.name}
                    </td>
                    {monitors.map((m) => (
                      <td key={m.id} className="px-3 py-2 text-center border-r border-slate-700/50 print:border-gray-400">
                        <span className={`font-medium ${getScore(dept.id, m.id) >= 70 ? 'text-emerald-400' : getScore(dept.id, m.id) >= 40 ? 'text-amber-400' : 'text-red-400'}`}>
                          {getScore(dept.id, m.id)}
                        </span>
                      </td>
                    ))}
                    <td className="px-3 py-2 text-right font-bold text-teal-400">
                      {total}
                    </td>
                  </tr>
                );
              })}
              {/* Totals Row */}
              <tr className="bg-slate-800/70 print:bg-gray-200 font-bold">
                <td colSpan={2} className="px-3 py-3 text-white print:text-black border-r border-slate-700 print:border-gray-400 sticky left-0 bg-slate-800/70 print:bg-gray-200">
                  TOTAL
                </td>
                {monitors.map((m) => (
                  <td key={m.id} className="px-3 py-3 text-center text-blue-400 border-r border-slate-700 print:border-gray-400">
                    {getMonitorTotal(m.id)}
                  </td>
                ))}
                <td className="px-3 py-3 text-right text-teal-400">
                  {grandTotal}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
