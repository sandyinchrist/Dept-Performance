import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import type { Department, FocusArea, MonthlyRecord } from '../types';
import { MONTHS, CURRENT_YEAR } from '../types';
import {
  Calendar,
  Save,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
  FileText,
  Check,
  RefreshCw,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface DepartmentDataEntryProps {
  departmentId: string;
  departmentName: string;
}

export function DepartmentDataEntry({ departmentId, departmentName }: DepartmentDataEntryProps) {
  const { user } = useAuth();
  const [year, setYear] = useState(CURRENT_YEAR);
  const [month, setMonth] = useState(new Date().getMonth());
  const [focusAreas, setFocusAreas] = useState<FocusArea[]>([]);
  const [records, setRecords] = useState<Map<string, MonthlyRecord>>(new Map());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [expandedRemark, setExpandedRemark] = useState<string | null>(null);
  const [showAddFocusArea, setShowAddFocusArea] = useState(false);
  const [newFocusAreaName, setNewFocusAreaName] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [faRes, recRes] = await Promise.all([
        supabase
          .from('focus_areas')
          .select('*')
          .eq('department_id', departmentId)
          .eq('is_active', true)
          .order('sort_order'),
        supabase
          .from('monthly_records')
          .select('*')
          .eq('department_id', departmentId)
          .eq('year', year)
          .eq('month', month + 1),
      ]);

      if (faRes.data) {
        setFocusAreas(faRes.data);
      }
      if (recRes.data) {
        const recordMap = new Map<string, MonthlyRecord>();
        recRes.data.forEach((r) => {
          // Sync annual_target from the focus area if available
          const fa = faRes.data?.find(f => f.id === r.focus_area_id);
          if (fa && r.annual_target !== fa.annual_target) {
            r.annual_target = fa.annual_target;
          }
          recordMap.set(r.focus_area_id, r);
        });
        setRecords(recordMap);
      }
    } catch (err) {
      console.error('Error fetching data:', err);
    }
    setLoading(false);
  }, [departmentId, year, month]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const getRecord = (focusAreaId: string, annualTarget: number): MonthlyRecord => {
    const existing = records.get(focusAreaId);
    if (existing) {
      // Ensure annual_target is synced from focus area
      return { ...existing, annual_target: annualTarget };
    }
    return {
      id: '',
      department_id: departmentId,
      focus_area_id: focusAreaId,
      year,
      month: month + 1,
      annual_target: annualTarget,
      monthly_target: 0,
      week1_achievement: 0,
      week2_achievement: 0,
      week3_achievement: 0,
      week4_achievement: 0,
      week5_achievement: 0,
      week1_remark: '',
      week2_remark: '',
      week3_remark: '',
      week4_remark: '',
      week5_remark: '',
      monthly_achievement: 0,
      monthly_percentage: 0,
      monthly_remark: '',
      previous_annual_achievement: 0,
      annual_total: 0,
      cumulative_annual_percentage: 0,
      annual_remark: '',
      created_at: '',
      updated_at: '',
    };
  };

  const updateRecord = (focusAreaId: string, updates: Partial<MonthlyRecord>) => {
    setRecords((prev) => {
      const newMap = new Map(prev);
      const current = newMap.get(focusAreaId) || getRecord(focusAreaId, focusAreas.find(f => f.id === focusAreaId)?.annual_target || 0);
      const updated = { ...current, ...updates };

      // Auto-calculate monthly achievement
      const monthlyAchievement =
        (Number(updated.week1_achievement) || 0) +
        (Number(updated.week2_achievement) || 0) +
        (Number(updated.week3_achievement) || 0) +
        (Number(updated.week4_achievement) || 0) +
        (Number(updated.week5_achievement) || 0);
      updated.monthly_achievement = monthlyAchievement;

      // Auto-calculate monthly percentage
      const monthlyTarget = Number(updated.monthly_target) || 0;
      if (monthlyTarget > 0) {
        updated.monthly_percentage = (monthlyAchievement / monthlyTarget) * 100;
      } else {
        updated.monthly_percentage = 0;
      }

      // Auto-calculate annual total
      const prevAnnual = Number(updated.previous_annual_achievement) || 0;
      updated.annual_total = prevAnnual + monthlyAchievement;

      // Auto-calculate cumulative annual percentage
      const annualTarget = Number(updated.annual_target) || 0;
      if (annualTarget > 0) {
        updated.cumulative_annual_percentage = (updated.annual_total / annualTarget) * 100;
      } else {
        updated.cumulative_annual_percentage = 0;
      }

      newMap.set(focusAreaId, updated);
      return newMap;
    });
  };

  const saveRecord = async (focusAreaId: string) => {
    const record = records.get(focusAreaId);
    if (!record) return;

    setSaving(true);
    try {
      const dataToSave = {
        department_id: departmentId,
        focus_area_id: focusAreaId,
        year,
        month: month + 1,
        annual_target: record.annual_target,
        monthly_target: record.monthly_target,
        week1_achievement: record.week1_achievement,
        week2_achievement: record.week2_achievement,
        week3_achievement: record.week3_achievement,
        week4_achievement: record.week4_achievement,
        week5_achievement: record.week5_achievement,
        week1_remark: record.week1_remark,
        week2_remark: record.week2_remark,
        week3_remark: record.week3_remark,
        week4_remark: record.week4_remark,
        week5_remark: record.week5_remark,
        monthly_achievement: record.monthly_achievement,
        monthly_percentage: record.monthly_percentage,
        monthly_remark: record.monthly_remark,
        previous_annual_achievement: record.previous_annual_achievement,
        annual_total: record.annual_total,
        cumulative_annual_percentage: record.cumulative_annual_percentage,
        annual_remark: record.annual_remark,
      };

      if (record.id) {
        await supabase.from('monthly_records').update(dataToSave).eq('id', record.id);
      } else {
        const { data } = await supabase.from('monthly_records').insert(dataToSave).select();
        if (data?.[0]) {
          setRecords((prev) => {
            const newMap = new Map(prev);
            newMap.set(focusAreaId, data[0]);
            return newMap;
          });
        }
      }
    } catch (err) {
      console.error('Error saving:', err);
    }
    setSaving(false);
  };

  const addFocusArea = async () => {
    if (!newFocusAreaName.trim()) return;
    const maxOrder = Math.max(...focusAreas.map((f) => f.sort_order), 0);
    const { data } = await supabase
      .from('focus_areas')
      .insert({
        department_id: departmentId,
        name: newFocusAreaName.trim(),
        sort_order: maxOrder + 1,
      })
      .select();
    if (data?.[0]) {
      setFocusAreas((prev) => [...prev, data[0]]);
    }
    setNewFocusAreaName('');
    setShowAddFocusArea(false);
  };

  const deleteFocusArea = async (id: string) => {
    if (!confirm('Are you sure you want to delete this focus area?')) return;
    await supabase.from('focus_areas').update({ is_active: false }).eq('id', id);
    setFocusAreas((prev) => prev.filter((f) => f.id !== id));
  };

  const getPreviousCumulative = async (focusAreaId: string): Promise<number> => {
    let cumulative = 0;
    for (let m = 0; m < month; m++) {
      const { data } = await supabase
        .from('monthly_records')
        .select('monthly_achievement')
        .eq('focus_area_id', focusAreaId)
        .eq('year', year)
        .eq('month', m + 1)
        .maybeSingle();
      if (data) {
        cumulative += data.monthly_achievement;
      }
    }
    return cumulative;
  };

  const loadPreviousCumulative = async () => {
    for (const fa of focusAreas) {
      const prev = await getPreviousCumulative(fa.id);
      const record = records.get(fa.id);
      if (record && record.previous_annual_achievement !== prev) {
        updateRecord(fa.id, { previous_annual_achievement: prev });
      }
    }
  };

  useEffect(() => {
    if (focusAreas.length > 0) {
      loadPreviousCumulative();
    }
  }, [month, year, focusAreas]);

  const inputClass =
    'w-full px-2 py-1.5 bg-slate-700/50 border border-slate-600 rounded text-sm text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-transparent';
  const numInputClass = 'w-20 px-2 py-1.5 bg-slate-700/50 border border-slate-600 rounded text-sm text-white text-right focus:outline-none focus:ring-1 focus:ring-emerald-500 focus:border-transparent';
  const calcClass = 'w-20 px-2 py-1.5 bg-slate-600/50 rounded text-sm text-right font-medium';

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">{departmentName}</h1>
          <p className="text-slate-400">Data Entry</p>
        </div>
        <div className="flex items-center gap-4">
          <select
            value={year}
            onChange={(e) => setYear(parseInt(e.target.value))}
            className="px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-xl text-white"
          >
            {[CURRENT_YEAR - 1, CURRENT_YEAR, CURRENT_YEAR + 1].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
          <select
            value={month}
            onChange={(e) => setMonth(parseInt(e.target.value))}
            className="px-4 py-2 bg-slate-700/50 border border-slate-600 rounded-xl text-white"
          >
            {MONTHS.map((m, i) => (
              <option key={i} value={i}>
                {m}
              </option>
            ))}
          </select>
          <button
            onClick={() => setShowAddFocusArea(true)}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Focus Area
          </button>
        </div>
      </div>

      {showAddFocusArea && (
        <div className="mb-4 p-4 bg-slate-800/50 border border-slate-700 rounded-xl flex items-center gap-4">
          <input
            type="text"
            value={newFocusAreaName}
            onChange={(e) => setNewFocusAreaName(e.target.value)}
            placeholder="Enter focus area name..."
            className="flex-1 px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-xl text-white"
            autoFocus
          />
          <button
            onClick={addFocusArea}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl"
          >
            Add
          </button>
          <button onClick={() => setShowAddFocusArea(false)} className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-xl">
            Cancel
          </button>
        </div>
      )}

      <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-800/50">
                <th className="px-3 py-3 text-left text-slate-300 font-medium border-r border-slate-700 sticky left-0 bg-slate-800/50 z-10 min-w-[40px]">
                  S/N
                </th>
                <th className="px-3 py-3 text-left text-slate-300 font-medium border-r border-slate-700 sticky left-[40px] bg-slate-800/50 z-10 min-w-[200px]">
                  Focus Area
                </th>
                <th className="px-3 py-3 text-center text-slate-300 font-medium border-r border-slate-700 min-w-[80px]">
                  Annual Target
                </th>
                <th className="px-3 py-3 text-center text-slate-300 font-medium border-r border-slate-700 min-w-[80px]">
                  Monthly Target
                </th>
                <th className="px-3 py-3 text-center text-emerald-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Wk 1
                </th>
                <th className="px-3 py-3 text-center text-slate-400 font-medium border-r border-slate-700 min-w-[120px]">
                  Wk 1 Remark
                </th>
                <th className="px-3 py-3 text-center text-emerald-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Wk 2
                </th>
                <th className="px-3 py-3 text-center text-slate-400 font-medium border-r border-slate-700 min-w-[120px]">
                  Wk 2 Remark
                </th>
                <th className="px-3 py-3 text-center text-emerald-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Wk 3
                </th>
                <th className="px-3 py-3 text-center text-slate-400 font-medium border-r border-slate-700 min-w-[120px]">
                  Wk 3 Remark
                </th>
                <th className="px-3 py-3 text-center text-emerald-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Wk 4
                </th>
                <th className="px-3 py-3 text-center text-slate-400 font-medium border-r border-slate-700 min-w-[120px]">
                  Wk 4 Remark
                </th>
                <th className="px-3 py-3 text-center text-emerald-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Wk 5
                </th>
                <th className="px-3 py-3 text-center text-slate-400 font-medium border-r border-slate-700 min-w-[120px]">
                  Wk 5 Remark
                </th>
                <th className="px-3 py-3 text-center text-teal-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Monthly Amt
                </th>
                <th className="px-3 py-3 text-center text-teal-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Monthly %
                </th>
                <th className="px-3 py-3 text-center text-slate-400 font-medium border-r border-slate-700 min-w-[150px]">
                  Monthly Remark
                </th>
                <th className="px-3 py-3 text-center text-blue-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Prev Annual
                </th>
                <th className="px-3 py-3 text-center text-blue-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Annual Total
                </th>
                <th className="px-3 py-3 text-center text-blue-400 font-medium border-r border-slate-700 min-w-[80px]">
                  Annual %
                </th>
                <th className="px-3 py-3 text-center text-slate-400 font-medium border-r border-slate-700 min-w-[150px]">
                  Annual Remark
                </th>
                <th className="px-3 py-3 text-center text-slate-300 font-medium min-w-[80px]">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {focusAreas.map((fa, idx) => {
                const record = records.get(fa.id) || getRecord(fa.id, fa.annual_target);
                return (
                  <tr key={fa.id} className="border-t border-slate-700/50 hover:bg-slate-700/20">
                    <td className="px-3 py-2 text-slate-400 border-r border-slate-700/50 bg-slate-800/30 sticky left-0">
                      {idx + 1}
                    </td>
                    <td className="px-3 py-2 text-white border-r border-slate-700/50 sticky left-[40px] bg-slate-800/30 z-10">
                      <input
                        type="text"
                        value={fa.name}
                        onChange={async (e) => {
                          const newName = e.target.value;
                          await supabase.from('focus_areas').update({ name: newName }).eq('id', fa.id);
                          setFocusAreas((prev) => prev.map((f) => (f.id === fa.id ? { ...f, name: newName } : f)));
                        }}
                        className="w-full bg-transparent border-none focus:outline-none"
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="number"
                        value={fa.annual_target}
                        onChange={async (e) => {
                          const newTarget = parseFloat(e.target.value) || 0;
                          await supabase.from('focus_areas').update({ annual_target: newTarget }).eq('id', fa.id);
                          setFocusAreas((prev) => prev.map((f) => (f.id === fa.id ? { ...f, annual_target: newTarget } : f)));
                          updateRecord(fa.id, { annual_target: newTarget });
                        }}
                        className={numInputClass}
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="number"
                        value={record.monthly_target}
                        onChange={(e) => updateRecord(fa.id, { monthly_target: parseFloat(e.target.value) || 0 })}
                        className={numInputClass}
                      />
                    </td>
                    {/* Week 1 */}
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="number"
                        value={record.week1_achievement}
                        onChange={(e) => updateRecord(fa.id, { week1_achievement: parseFloat(e.target.value) || 0 })}
                        className={numInputClass}
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="text"
                        value={record.week1_remark}
                        onChange={(e) => updateRecord(fa.id, { week1_remark: e.target.value })}
                        className={inputClass}
                        placeholder="Remark..."
                      />
                    </td>
                    {/* Week 2 */}
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="number"
                        value={record.week2_achievement}
                        onChange={(e) => updateRecord(fa.id, { week2_achievement: parseFloat(e.target.value) || 0 })}
                        className={numInputClass}
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="text"
                        value={record.week2_remark}
                        onChange={(e) => updateRecord(fa.id, { week2_remark: e.target.value })}
                        className={inputClass}
                        placeholder="Remark..."
                      />
                    </td>
                    {/* Week 3 */}
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="number"
                        value={record.week3_achievement}
                        onChange={(e) => updateRecord(fa.id, { week3_achievement: parseFloat(e.target.value) || 0 })}
                        className={numInputClass}
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="text"
                        value={record.week3_remark}
                        onChange={(e) => updateRecord(fa.id, { week3_remark: e.target.value })}
                        className={inputClass}
                        placeholder="Remark..."
                      />
                    </td>
                    {/* Week 4 */}
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="number"
                        value={record.week4_achievement}
                        onChange={(e) => updateRecord(fa.id, { week4_achievement: parseFloat(e.target.value) || 0 })}
                        className={numInputClass}
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="text"
                        value={record.week4_remark}
                        onChange={(e) => updateRecord(fa.id, { week4_remark: e.target.value })}
                        className={inputClass}
                        placeholder="Remark..."
                      />
                    </td>
                    {/* Week 5 */}
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="number"
                        value={record.week5_achievement}
                        onChange={(e) => updateRecord(fa.id, { week5_achievement: parseFloat(e.target.value) || 0 })}
                        className={numInputClass}
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="text"
                        value={record.week5_remark}
                        onChange={(e) => updateRecord(fa.id, { week5_remark: e.target.value })}
                        className={inputClass}
                        placeholder="Remark..."
                      />
                    </td>
                    {/* Calculated Fields */}
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <div className={calcClass + ' text-teal-400'}>{record.monthly_achievement.toFixed(2)}</div>
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <div className={calcClass + ' text-teal-400'}>{record.monthly_percentage.toFixed(1)}%</div>
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="text"
                        value={record.monthly_remark}
                        onChange={(e) => updateRecord(fa.id, { monthly_remark: e.target.value })}
                        className={inputClass}
                        placeholder="Remark..."
                      />
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <div className={calcClass + ' text-blue-400'}>{record.previous_annual_achievement.toFixed(2)}</div>
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <div className={calcClass + ' text-blue-400'}>{record.annual_total.toFixed(2)}</div>
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <div className={calcClass + ' text-blue-400'}>{record.cumulative_annual_percentage.toFixed(1)}%</div>
                    </td>
                    <td className="px-2 py-2 border-r border-slate-700/50">
                      <input
                        type="text"
                        value={record.annual_remark}
                        onChange={(e) => updateRecord(fa.id, { annual_remark: e.target.value })}
                        className={inputClass}
                        placeholder="Remark..."
                      />
                    </td>
                    <td className="px-2 py-2">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => saveRecord(fa.id)}
                          disabled={saving}
                          className="p-1.5 text-emerald-400 hover:bg-emerald-500/20 rounded transition-colors"
                          title="Save"
                        >
                          <Save className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteFocusArea(fa.id)}
                          className="p-1.5 text-red-400 hover:bg-red-500/20 rounded transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Executive Summary for Department */}
      <div className="mt-6 p-6 bg-slate-800/30 border border-slate-700/50 rounded-xl">
        <h2 className="text-xl font-bold text-white mb-4">Executive Summary</h2>
        <div className="grid grid-cols-2 gap-6">
          <div className="p-4 bg-slate-700/30 rounded-xl">
            <p className="text-slate-400 text-sm">Monthly Achievement Percentage</p>
            <p className="text-3xl font-bold text-emerald-400 mt-1">
              {(() => {
                const totalMonthlyTarget = Array.from(records.values()).reduce((sum, r) => sum + (r.monthly_target || 0), 0);
                const totalMonthlyAchievement = Array.from(records.values()).reduce((sum, r) => sum + (r.monthly_achievement || 0), 0);
                if (totalMonthlyTarget === 0) return '0.0%';
                return ((totalMonthlyAchievement / totalMonthlyTarget) * 100).toFixed(1) + '%';
              })()}
            </p>
          </div>
          <div className="p-4 bg-slate-700/30 rounded-xl">
            <p className="text-slate-400 text-sm">Cumulative Annual Percentage</p>
            <p className="text-3xl font-bold text-blue-400 mt-1">
              {(() => {
                const totalAnnualTarget = Array.from(records.values()).reduce((sum, r) => sum + (r.annual_target || 0), 0);
                const totalAnnual = Array.from(records.values()).reduce((sum, r) => sum + (r.annual_total || 0), 0);
                if (totalAnnualTarget === 0) return '0.0%';
                return ((totalAnnual / totalAnnualTarget) * 100).toFixed(1) + '%';
              })()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
